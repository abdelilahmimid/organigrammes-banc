// =====================================================================
//  thermique.cpp : température du frein (DS18B20 sur D48) et ventilation
// ---------------------------------------------------------------------
//  La conversion 12 bits de la DS18B20 dure ~750 ms : à chaque passage
//  (toutes les 1 s) on lit le résultat de la conversion précédente puis
//  on en relance une, sans jamais attendre.
//
//  Les ventilateurs suivent la température, pas l'état du frein : ils
//  restent en marche après un arrêt tant que la bobine est chaude.
//  Une seule broche (D42) commande les deux relais.
// =====================================================================
#include "banc.h"
#include <OneWire.h>
#include <DallasTemperature.h>

static OneWire s_bus(BROCHE_SONDE_TEMP);
static DallasTemperature s_sonde(&s_bus);
static uint8_t s_nb_echecs = 0;

void ventilateurs_commander(bool on) {
  digitalWrite(BROCHE_VENTILATEURS, on ? VENTILATEURS_NIVEAU_ON : !VENTILATEURS_NIVEAU_ON);
  g_mesures.ventilateurs_on = on;
}

void thermique_init() {
  pinMode(BROCHE_VENTILATEURS, OUTPUT);
  ventilateurs_commander(false);

  s_sonde.begin();
  s_sonde.setResolution(12);
  s_sonde.setWaitForConversion(false);  // conversion non bloquante
  s_sonde.requestTemperatures();        // première conversion
  g_mesures.temperature_C = NAN;
  g_mesures.sonde_ok = false;
}

void thermique_tache() {
  float t = s_sonde.getTempCByIndex(0);   // conversion lancée il y a 1 s
  s_sonde.requestTemperatures();          // relance pour le prochain passage

  if (t == DEVICE_DISCONNECTED_C) {
    // Sonde absente ou bus en panne : ventilation par sécurité
    ventilateurs_commander(true);
    if (s_nb_echecs < 255) s_nb_echecs++;
    if (s_nb_echecs >= SONDE_NB_ECHECS_DEFAUT) {
      g_mesures.sonde_ok = false;
      defaut(DEFAUT_SONDE);
    }
    return;
  }
  s_nb_echecs = 0;
  g_mesures.sonde_ok = true;
  g_mesures.temperature_C = t;

  if (t >= TEMP_DEFAUT_C) {
    ventilateurs_commander(true);
    defaut(DEFAUT_SURCHAUFFE);
  } else if (g_mesures.mode == MODE_DEFAUT) {
    ventilateurs_commander(true);         // en défaut, on refroidit toujours
  } else if (t >= TEMP_VENTIL_ON_C) {
    ventilateurs_commander(true);
  } else if (t <= TEMP_VENTIL_OFF_C) {
    ventilateurs_commander(false);
  }
  // entre 50 et 60 °C : on ne change rien (hystérésis du relais)
}
