// =====================================================================
//  banc.h : types et fonctions partagés entre les modules
// =====================================================================
#pragma once
#include <Arduino.h>
#include "config.h"

// ----- Modes du banc (machine d'états) -------------------------------
enum ModeBanc : uint8_t {
  MODE_ATTENTE = 0,   // prêt, frein coupé
  MODE_ESSAI,         // le frein simule la pente
  MODE_FREINAGE,      // freinage progressif de fin d'essai
  MODE_DEFAUT         // tout est mis en sécurité, attente d'acquittement
};

// ----- Causes de défaut ----------------------------------------------
enum CauseDefaut : uint8_t {
  DEFAUT_AUCUN = 0,
  DEFAUT_FREIN_URGENCE,   // contact D3 actionné
  DEFAUT_SURCHAUFFE,      // T >= 100 °C
  DEFAUT_SONDE,           // DS18B20 absente
  DEFAUT_CAPTEUR_COUPLE,  // tension A0 hors plage
  DEFAUT_SURVITESSE,      // rouleau trop rapide
  DEFAUT_PC_MUET          // plus de message du PC (quand la liaison existera)
};

// ----- Réponses aux demandes (démarrer, arrêter, acquitter) ----------
enum Reponse : uint8_t {
  REP_OK = 0,
  REP_ERR_MODE,           // demande impossible dans le mode actuel
  REP_ERR_FREIN_URGENCE,  // frein mécanique serré
  REP_ERR_VITESSE,        // rouleau pas arrêté
  REP_ERR_TEMPERATURE,    // frein trop chaud (>= 95 °C)
  REP_ERR_CAPTEUR,        // sonde ou couplemètre en défaut
  REP_ERR_PENTE           // pente hors 0 à 6 % (ou pas un nombre)
};

// ----- Toutes les mesures, mises à jour par les tâches ----------------
struct Mesures {
  uint32_t t_ms;            // horodatage millis()
  ModeBanc mode;
  CauseDefaut defaut;
  float rpm_rouleau;        // tr/min
  float vitesse_kmh;        // vitesse linéaire du pneu sur le rouleau
  float couple_rouleau_Nm;  // couple mesuré par le DYN-200
  float puissance_W;        // couple x vitesse angulaire du rouleau
  float temperature_C;      // bobine du frein, NAN si pas encore lue
  bool  sonde_ok;
  bool  ventilateurs_on;
  bool  frein_urgence_serre;
  float pente_pct;          // pente demandée (%), gardée d'un essai à l'autre
  float consigne_couple_Nm; // consigne au volant (suit la pente par rampe)
  float couple_frein_estime_Nm; // estimation au volant (mesure - inertie)
  float alpha;              // rapport cyclique appliqué au frein (0..0,95)
  bool  frein_sature;       // la pente demandée n'est plus tenue
};

extern Mesures g_mesures;

// ----- Point d'accroche : consigne de couple --------------------------
// Couple de freinage voulu AU VOLANT pendant l'essai (N·m). Aujourd'hui il
// est fixé par definirPente() ; plus tard la liaison PC l'écrira.
extern volatile float g_consigne_couple_essai_Nm;

// ----- mesures.cpp ----------------------------------------------------
void mesures_init();
void mesures_echantillonCouple();   // toutes les 1 ms
void mesures_calculer(float dt_s);  // toutes les 10 ms

// ----- frein.cpp ------------------------------------------------------
void frein_init();
void frein_couper();                // PWM coupé, les deux MOSFET bloqués
void frein_appliquerAlpha(float alpha);
float frein_alphaDepuisCouple(float couple_volant_Nm);
void frein_reguler(float dt_s);     // toutes les 10 ms
float couplePourPente(float pente_pct);

// ----- thermique.cpp --------------------------------------------------
void thermique_init();
void thermique_tache();             // toutes les 1 s
void ventilateurs_commander(bool on);

// ----- etats.cpp ------------------------------------------------------
void etats_init();
void etats_tache();                 // à chaque tour de loop()
void defaut(CauseDefaut cause);
bool frein_urgence_lire();

// Demandes externes (appelées plus tard par la liaison PC)
Reponse demanderDemarrage();
Reponse demanderArret();
Reponse demanderAcquittement();
Reponse definirPente(float pente_pct);
void    signalerActivitePC();

// ----- commandes.cpp : commandes série (p3.5, SET_SLOPE...) et DATA ---
void commandes_tache();             // à chaque tour de loop()
void commandes_envoyerTrame(const Mesures& m);  // toutes les 50 ms

// ----- crochets.cpp ------------------------------------------------------
void journalMesures(const Mesures& m);
void evenementDefaut(CauseDefaut cause);
void evenementChangementMode(ModeBanc ancien, ModeBanc nouveau);
void evenementSaturationFrein(bool sature);
void prototype_tache();

const char* nomMode(ModeBanc m);
const char* nomDefaut(CauseDefaut c);
