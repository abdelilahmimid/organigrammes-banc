// =====================================================================
//  frein.cpp : pilotage du frein à hystérésis (PWM Timer 4 + PI)
// ---------------------------------------------------------------------
//  Le driver MIC4104 commande un demi-pont (Q1 en haut, Q2 en bas) sur
//  le 24 V. Le rapport cyclique alpha fixe la tension moyenne sur la
//  bobine, donc le courant, donc le couple de freinage.
//
//  Timer 4 en PWM phase correcte, TOP = ICR4 = 400 à 16 MHz :
//      f = 16 MHz / (2 x 400) = 20 kHz
//  D6 (OC4A, PWMH) : non inversé, à 1 tant que TCNT4 < OCR4A
//  D7 (OC4B, PWML) : inversé,     à 1 tant que TCNT4 > OCR4B
//  Avec OCR4B = OCR4A + 8, les deux MOSFET ne conduisent jamais ensemble :
//  8 pas de 62,5 ns = 0,5 µs de temps mort de chaque côté.
// =====================================================================
#include "banc.h"

volatile float g_consigne_couple_essai_Nm = 0.0f;

static float s_integrale = 0.0f;       // terme intégral du PI
static float s_consigne = 0.0f;        // consigne réellement suivie (rampe)
static float s_omega_volant_prec = 0.0f;
static float s_accel_filtree = 0.0f;   // dω/dt du volant, filtrée
static uint16_t s_duree_sature_ms = 0; // temps passé saturé (voir config.h)
static ModeBanc s_mode_prec = MODE_ATTENTE;
static bool s_pwm_actif = false;

// ----- Bas niveau : Timer 4 --------------------------------------------
void frein_init() {
  digitalWrite(BROCHE_PWMH, LOW);
  digitalWrite(BROCHE_PWML, LOW);
  pinMode(BROCHE_PWMH, OUTPUT);
  pinMode(BROCHE_PWML, OUTPUT);

  TCCR4A = 0;
  TCCR4B = 0;
  TCNT4  = 0;
  ICR4   = PWM_TOP;
  OCR4A  = 0;
  OCR4B  = 0;
  // Mode 10 : PWM phase correcte, TOP = ICR4 ; pas de prédiviseur
  TCCR4A = _BV(WGM41);
  TCCR4B = _BV(WGM43) | _BV(CS40);
  frein_couper();
}

// Les deux sorties sont détachées du timer et forcées à 0 :
// les deux MOSFET sont bloqués, la bobine se décharge par la diode du
// MOSFET bas.
void frein_couper() {
  TCCR4A &= ~(_BV(COM4A1) | _BV(COM4A0) | _BV(COM4B1) | _BV(COM4B0));
  digitalWrite(BROCHE_PWMH, LOW);
  digitalWrite(BROCHE_PWML, LOW);
  OCR4A = 0;
  OCR4B = 0;
  s_pwm_actif = false;
  g_mesures.alpha = 0.0f;
}

void frein_appliquerAlpha(float alpha) {
  if (!(alpha > 0.0f)) {             // 0, négatif ou NAN
    frein_couper();
    return;
  }
  if (alpha > ALPHA_MAX) alpha = ALPHA_MAX;

  uint16_t ocr_a = (uint16_t)(alpha * PWM_TOP + 0.5f);
  uint16_t ocr_b = ocr_a + PWM_TEMPS_MORT;
  if (ocr_b > PWM_TOP) ocr_b = PWM_TOP;

  OCR4A = ocr_a;                       // mis à jour au prochain TOP
  OCR4B = ocr_b;
  if (!s_pwm_actif) {
    // Rattacher les sorties au timer : A non inversée, B inversée
    TCCR4A |= _BV(COM4A1) | _BV(COM4B1) | _BV(COM4B0);
    s_pwm_actif = true;
  }
  g_mesures.alpha = alpha;
}

// ----- Consigne -----------------------------------------------------
// Couple au volant qui imite une pente (115 kg, Excel « Calcul »).
// Le poids du prototype dans la pente vaut m.g.sin(a) avec tan(a) = p/100 ;
// jusqu'à 6 %, sin(a) et p/100 diffèrent de moins de 0,2 %, d'où une
// simple proportion. Le couple est le même à toute vitesse (une pente
// freine pareil à 5 et à 30 km/h) ; c'est la puissance qui monte.
// Exemple : 3 % -> 0,66 N·m ; 6 % -> 1,32 N·m.
float couplePourPente(float pente_pct) {
  return COUPLE_PAR_PCT_PENTE * pente_pct;
}

// Rapproche s_consigne de la cible d'au plus « pas » (rampe symétrique)
static void rampeVers(float cible, float pas) {
  if (s_consigne < cible - pas)      s_consigne += pas;
  else if (s_consigne > cible + pas) s_consigne -= pas;
  else                               s_consigne = cible;
}

// Signale le frein saturé quand la pente n'est plus tenue depuis un moment
static void surveillerSaturation(bool sature_maintenant, float dt_s) {
  if (sature_maintenant) {
    uint16_t dt_ms = (uint16_t)(dt_s * 1000.0f + 0.5f);
    if (s_duree_sature_ms < SATURATION_DELAI_MS) s_duree_sature_ms += dt_ms;
  } else {
    s_duree_sature_ms = 0;
  }
  bool sature = (s_duree_sature_ms >= SATURATION_DELAI_MS);
  if (sature != g_mesures.frein_sature) {
    g_mesures.frein_sature = sature;
    evenementSaturationFrein(sature);
  }
}

// Anticipation : couple voulu -> courant -> rapport cyclique.
// Exemple : 0,66 N·m -> 0,176 A -> alpha = 0,176 x 64 / 24 = 0,469.
// À froid seulement : la résistance de la bobine monte d'environ 30 %
// entre 20 et 100 °C, c'est le PI qui rattrape l'écart.
float frein_alphaDepuisCouple(float couple_volant_Nm) {
  if (couple_volant_Nm <= 0.0f) return 0.0f;
  float courant_A = couple_volant_Nm / FREIN_NM_PAR_A;
  float alpha = courant_A * RESISTANCE_BOBINE_OHM / TENSION_FREIN_V;
  return (alpha > ALPHA_MAX) ? ALPHA_MAX : alpha;
}

// ----- Régulation, toutes les 10 ms ---------------------------------
void frein_reguler(float dt_s) {
  ModeBanc mode = g_mesures.mode;

  // Accélération du volant (dérivée filtrée), utile pour estimer le
  // couple du frein seul : C_rouleau / 4 = J.dω/dt + C_frein
  float omega_volant = g_mesures.rpm_rouleau * RAPPORT_COURROIE * (2.0f * PI / 60.0f);
  float accel = (omega_volant - s_omega_volant_prec) / dt_s;
  s_omega_volant_prec = omega_volant;
  s_accel_filtree += 0.1f * (accel - s_accel_filtree);  // passe-bas ~100 ms
  float couple_frein = g_mesures.couple_rouleau_Nm / RAPPORT_COURROIE
                       - INERTIE_VOLANT_KGM2 * s_accel_filtree;
  g_mesures.couple_frein_estime_Nm = couple_frein;

  // Entrée dans un nouveau mode : on repart d'une intégrale nulle.
  // s_consigne n'est pas touchée : le freinage de fin part du couple
  // réellement appliqué, et un essai part de 0 (remis à 0 en ATTENTE).
  if (mode != s_mode_prec) {
    s_integrale = 0.0f;
    s_mode_prec = mode;
  }
  if (mode != MODE_ESSAI) surveillerSaturation(false, dt_s);

  switch (mode) {
    case MODE_ESSAI:
      // La consigne rejoint la pente demandée par rampe : au départ de
      // l'essai et à chaque changement de pente pendant l'essai.
      rampeVers(g_consigne_couple_essai_Nm, RAMPE_PENTE_NM_PAR_S * dt_s);
      break;

    case MODE_FREINAGE:
      // Le couple monte par rampe jusqu'au couple d'arrêt
      s_consigne += RAMPE_ARRET_NM_PAR_S * dt_s;
      if (s_consigne > COUPLE_ARRET_NM) s_consigne = COUPLE_ARRET_NM;
      break;

    case MODE_DEFAUT:
      // Boucle ouverte (le capteur de couple est peut-être en cause).
      // Le frein aide le frein à disque tant que la bobine n'est pas
      // trop chaude et que le rouleau tourne, puis il est coupé.
      g_mesures.consigne_couple_Nm = 0.0f;
      if (g_mesures.rpm_rouleau >= RPM_ARRET &&
          g_mesures.sonde_ok &&
          g_mesures.temperature_C < TEMP_DEFAUT_C) {
        frein_appliquerAlpha(ALPHA_URGENCE);
      } else {
        frein_couper();
      }
      return;

    case MODE_ATTENTE:
    default:
      g_mesures.consigne_couple_Nm = 0.0f;
      s_consigne = 0.0f;
      frein_couper();
      return;
  }
  g_mesures.consigne_couple_Nm = s_consigne;

  // --- Anticipation + correcteur PI ---
  float alpha_ff = frein_alphaDepuisCouple(s_consigne);
  float erreur = s_consigne - couple_frein;
  bool pi_actif = (g_mesures.rpm_rouleau >= PI_RPM_MIN) && (s_consigne > 0.0f);
  if (!pi_actif) {
    s_integrale = 0.0f;
    frein_appliquerAlpha(alpha_ff);
    if (mode == MODE_ESSAI) surveillerSaturation(false, dt_s);
    return;
  }

  float alpha = alpha_ff + PI_KP * erreur + s_integrale;
  bool sature_haut = (alpha >= ALPHA_MAX) && (erreur > 0.0f);
  bool sature_bas  = (alpha <= 0.0f) && (erreur < 0.0f);
  bool accel_forte = fabs(s_accel_filtree) > PI_ACCEL_MAX;
  // Anti-emballement : l'intégrale est figée si la sortie est saturée
  // dans le sens de l'erreur, ou si l'accélération rend l'estimation
  // du couple du frein trop incertaine.
  if (!sature_haut && !sature_bas && !accel_forte) {
    s_integrale += PI_KI * erreur * dt_s;
  }
  alpha = alpha_ff + PI_KP * erreur + s_integrale;
  if (alpha < 0.0f) alpha = 0.0f;
  frein_appliquerAlpha(alpha);

  // Pente non tenue : frein au maximum et couple encore trop faible.
  // Seulement en ESSAI : en FREINAGE, la saturation est voulue.
  if (mode == MODE_ESSAI) {
    surveillerSaturation(alpha >= ALPHA_MAX && erreur > SATURATION_ECART_NM, dt_s);
  }
}
