// =====================================================================
//  etats.cpp : machine d'états du banc et arrêt d'urgence
// ---------------------------------------------------------------------
//    ATTENTE  --demanderDemarrage() et tout est sûr-->  ESSAI
//    ESSAI    --demanderArret()-->                      FREINAGE
//    FREINAGE --rouleau < 5 tr/min-->                   ATTENTE
//    tout mode --frein d'urgence, surchauffe, sonde, couplemètre,
//                survitesse, PC muet-->                 DÉFAUT
//    DÉFAUT   --demanderAcquittement() et tout est sûr--> ATTENTE
//
//  Le banc ne démarre jamais seul. En DÉFAUT, le frein à hystérésis aide
//  le frein à disque (voir frein.cpp), les ventilateurs tournent, et il
//  faut un acquittement pour repartir.
// =====================================================================
#include "banc.h"

static volatile bool s_urgence_isr = false;  // levé par l'interruption D3
static bool s_demande_ack = false;
static uint32_t s_t_dernier_msg_pc = 0;

// ----- Frein d'arrêt d'urgence (D3) ---------------------------------
bool frein_urgence_lire() {
  return digitalRead(BROCHE_FREIN_URGENCE) == FREIN_URGENCE_NIVEAU_ACTIF;
}

// Interruption sur tout changement de D3 : on note seulement l'événement,
// loop() le traite au tour suivant (quelques dizaines de µs).
static void isrFreinUrgence() {
  if (digitalRead(BROCHE_FREIN_URGENCE) == FREIN_URGENCE_NIVEAU_ACTIF) {
    s_urgence_isr = true;
  }
}

static void changerMode(ModeBanc nouveau) {
  ModeBanc ancien = g_mesures.mode;
  if (ancien == nouveau) return;
  g_mesures.mode = nouveau;
  evenementChangementMode(ancien, nouveau);
}

// Passe le banc en DÉFAUT. Le premier défaut est mémorisé comme cause ;
// les suivants ne l'écrasent pas tant qu'il n'est pas acquitté.
void defaut(CauseDefaut cause) {
  if (g_mesures.mode == MODE_DEFAUT) return;
  g_mesures.defaut = cause;
  s_demande_ack = false;
  changerMode(MODE_DEFAUT);
  ventilateurs_commander(true);
  evenementDefaut(cause);
}

// Conditions communes pour démarrer un essai ou sortir du défaut
static Reponse verifierSecurite() {
  if (frein_urgence_lire())                 return REP_ERR_FREIN_URGENCE;
  if (g_mesures.rpm_rouleau >= RPM_ARRET)   return REP_ERR_VITESSE;
  if (!g_mesures.sonde_ok)                  return REP_ERR_CAPTEUR;
  if (g_mesures.temperature_C >= TEMP_REPRISE_C) return REP_ERR_TEMPERATURE;
  float v = analogRead(BROCHE_COUPLE) * TENSION_REF_ADC_V / 1023.0f;
  if (v < COUPLE_TENSION_MIN_V || v > COUPLE_TENSION_MAX_V) return REP_ERR_CAPTEUR;
  return REP_OK;
}

void etats_init() {
  pinMode(BROCHE_FREIN_URGENCE, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(BROCHE_FREIN_URGENCE), isrFreinUrgence, CHANGE);
  g_mesures.mode = MODE_ATTENTE;
  g_mesures.defaut = DEFAUT_AUCUN;
  s_t_dernier_msg_pc = millis();
  if (frein_urgence_lire()) defaut(DEFAUT_FREIN_URGENCE);
}

// À chaque tour de loop() : surveillance et transitions automatiques
void etats_tache() {
  // 1. Frein d'urgence : interruption OU lecture directe (si un front a
  //    été manqué, le niveau suffit)
  bool urgence = frein_urgence_lire();
  g_mesures.frein_urgence_serre = urgence;
  if (s_urgence_isr || urgence) {
    s_urgence_isr = false;
    s_demande_ack = false;   // un acquittement donné avant ne compte plus
    defaut(DEFAUT_FREIN_URGENCE);
  }

  // 2. PC muet pendant un essai (actif quand la liaison PC existera)
  if (CONTROLE_PC_ACTIF &&
      (g_mesures.mode == MODE_ESSAI || g_mesures.mode == MODE_FREINAGE) &&
      millis() - s_t_dernier_msg_pc > DELAI_PC_MUET_MS) {
    defaut(DEFAUT_PC_MUET);
  }

  // 3. Transitions automatiques
  switch (g_mesures.mode) {
    case MODE_FREINAGE:
      if (g_mesures.rpm_rouleau < RPM_ARRET) changerMode(MODE_ATTENTE);
      break;

    case MODE_DEFAUT:
      if (s_demande_ack) {
        if (verifierSecurite() == REP_OK) {
          s_demande_ack = false;
          g_mesures.defaut = DEFAUT_AUCUN;
          changerMode(MODE_ATTENTE);
        }
      }
      break;

    default:
      break;
  }
}

// ----- Demandes externes (plus tard : commandes du PC) ----------------
Reponse demanderDemarrage() {
  if (g_mesures.mode != MODE_ATTENTE) return REP_ERR_MODE;
  Reponse r = verifierSecurite();
  if (r != REP_OK) return r;
  changerMode(MODE_ESSAI);
  return REP_OK;
}

Reponse demanderArret() {
  if (g_mesures.mode == MODE_ESSAI) {
    changerMode(MODE_FREINAGE);
    return REP_OK;
  }
  if (g_mesures.mode == MODE_FREINAGE || g_mesures.mode == MODE_ATTENTE) return REP_OK;
  return REP_ERR_MODE;  // en DÉFAUT, il faut acquitter
}

// L'acquittement est mémorisé ; la sortie du défaut se fait dès que les
// conditions de sécurité sont réunies (rouleau arrêté, D3 relâché, etc.)
Reponse demanderAcquittement() {
  if (g_mesures.mode != MODE_DEFAUT) return REP_ERR_MODE;
  s_demande_ack = true;
  return REP_OK;
}

// Pente acceptée dans tous les modes, y compris pendant l'essai : le
// frein la rejoint par rampe (frein.cpp). Elle est gardée pour l'essai
// suivant. Une pente refusée ne change pas la pente en cours.
Reponse definirPente(float pente_pct) {
  if (!(pente_pct >= 0.0f && pente_pct <= PENTE_MAX_PCT)) return REP_ERR_PENTE;
  g_mesures.pente_pct = pente_pct;
  g_consigne_couple_essai_Nm = couplePourPente(pente_pct);
  return REP_OK;
}

// À appeler à chaque message reçu du PC (chien de garde de la liaison)
void signalerActivitePC() {
  s_t_dernier_msg_pc = millis();
}
