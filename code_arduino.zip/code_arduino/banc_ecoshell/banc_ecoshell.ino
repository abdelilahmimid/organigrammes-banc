// =====================================================================
//  Banc de test à rouleau Ecoshell : programme de l'Arduino Mega 2560
//  Partie autonome + commande de la pente par le port série
// ---------------------------------------------------------------------
//  Fichiers :
//    config.h        broches, seuils, constantes ([HYPOTHÈSE] à valider)
//    banc.h          types et fonctions partagés
//    mesures.cpp     vitesse (D2) et couple (A0)
//    frein.cpp       PWM 20 kHz du frein à hystérésis + correcteur PI
//    thermique.cpp   DS18B20 (D48) et ventilateurs (D42)
//    etats.cpp       modes du banc, arrêt d'urgence (D3)
//    commandes.cpp   commandes série (pente p3.5 / SET_SLOPE) et trame DATA
//    crochets.cpp    événements vers le PC (FAULT, MODE, BRAKE_SAT)
//
//  Bibliothèques : OneWire, DallasTemperature (gestionnaire de bibliothèques)
//
//  Organisation : aucune attente bloquante. Chaque tâche compare millis()
//  à sa propre période ; le chien de garde matériel redémarre la carte
//  (frein coupé) si le programme se bloque plus de 250 ms.
// =====================================================================
#include <avr/wdt.h>
#include "banc.h"

Mesures g_mesures;

static uint32_t t_echantillon = 0;
static uint32_t t_regulation  = 0;
static uint32_t t_journal     = 0;
static uint32_t t_thermique   = 0;

// Met les périphériques non utilisés en V1 dans un état sûr
static void desactiverLiaisonsNonUtilisees() {
  // SPI vers le prototype : SS au repos (inactif), Mega maître plus tard
  pinMode(BROCHE_SPI_SS, OUTPUT);
  digitalWrite(BROCHE_SPI_SS, HIGH);
  // MAX485 : émetteur coupé, récepteur coupé (D0/D1 restent à l'USB)
  if (BROCHE_MAX485_DE != 255) { pinMode(BROCHE_MAX485_DE, OUTPUT); digitalWrite(BROCHE_MAX485_DE, LOW); }
  if (BROCHE_MAX485_RE != 255) { pinMode(BROCHE_MAX485_RE, OUTPUT); digitalWrite(BROCHE_MAX485_RE, HIGH); }
}

void setup() {
  wdt_disable();

  // 1. Tout à l'arrêt avant toute autre chose
  memset(&g_mesures, 0, sizeof(g_mesures));
  frein_init();               // frein coupé
  thermique_init();           // ventilateurs coupés, sonde prête
  desactiverLiaisonsNonUtilisees();

  // 2. Capteurs et machine d'états
  Serial.begin(115200);
  mesures_init();
  etats_init();               // passe en DÉFAUT si D3 est déjà actif

  wdt_enable(WDTO_250MS);

  uint32_t t = millis();
  t_echantillon = t_regulation = t_journal = t_thermique = t;
}

void loop() {
  wdt_reset();
  uint32_t maintenant = millis();

  // Sécurité d'abord, à chaque tour
  etats_tache();

  // Commandes série : p3.5 / SET_SLOPE:3.5, START, STOP, ACK
  commandes_tache();

  // 1 ms : un échantillon de couple
  if (maintenant - t_echantillon >= PERIODE_ECHANTILLON_MS) {
    t_echantillon = maintenant;
    mesures_echantillonCouple();
  }

  // 10 ms : vitesse, couple, puis frein
  if (maintenant - t_regulation >= PERIODE_REGULATION_MS) {
    float dt_s = (maintenant - t_regulation) / 1000.0f;
    t_regulation = maintenant;
    mesures_calculer(dt_s);
    etats_tache();            // réagir tout de suite à un défaut mesuré
    frein_reguler(dt_s);
  }

  // 50 ms : trame DATA vers le PC
  if (maintenant - t_journal >= PERIODE_JOURNAL_MS) {
    t_journal = maintenant;
    g_mesures.t_ms = maintenant;
    journalMesures(g_mesures);
  }

  // 1 s : température et ventilation
  if (maintenant - t_thermique >= PERIODE_THERMIQUE_MS) {
    t_thermique = maintenant;
    thermique_tache();
  }

  prototype_tache();          // vide en V1
}
