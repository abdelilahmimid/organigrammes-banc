// =====================================================================
//  mesures.cpp : vitesse (impulsions sur D2) et couple (A0)
// ---------------------------------------------------------------------
//  Le DYN-200 est monté sur l'arbre du rouleau : 60 impulsions par tour
//  du rouleau, pas de rapport 4 dans le calcul de la vitesse.
//  En V1 le MAX485 n'est pas utilisé (il partage D0/D1 avec l'USB) : le
//  couple est lu uniquement sur la sortie analogique SIG_OUT.
// =====================================================================
#include "banc.h"

// ----- Vitesse : variables partagées avec l'interruption ---------------
static volatile uint32_t s_nb_impulsions = 0;   // compteur total
static volatile uint32_t s_t_derniere_us = 0;   // heure du dernier front
static volatile uint32_t s_periode_us    = 0;   // dernière période

// Valeurs mémorisées d'une fenêtre de 10 ms à la suivante
static uint32_t s_nb_prec = 0;
static uint32_t s_t_prec_us = 0;

// ----- Couple : moyenne des échantillons de 1 ms ----------------------
static uint32_t s_somme_adc = 0;
static uint16_t s_nb_adc = 0;
static uint8_t  s_nb_hors_plage = 0;

// Interruption : un front montant = 1/60 de tour du rouleau
static void isrVitesse() {
  uint32_t t = micros();
  s_periode_us = t - s_t_derniere_us;
  s_t_derniere_us = t;
  s_nb_impulsions++;
}

void mesures_init() {
  pinMode(BROCHE_VITESSE, INPUT);  // tirage par R16 sur la carte
  attachInterrupt(digitalPinToInterrupt(BROCHE_VITESSE), isrVitesse, RISING);
  s_t_prec_us = micros();
}

// Appelée toutes les 1 ms : ajoute un échantillon de A0 à la moyenne.
void mesures_echantillonCouple() {
  s_somme_adc += analogRead(BROCHE_COUPLE);
  s_nb_adc++;
}

// Appelée toutes les 10 ms : vitesse, couple, puissance.
void mesures_calculer(float dt_s) {
  (void)dt_s;

  // --- Copie atomique des variables de l'interruption ---
  noInterrupts();
  uint32_t nb = s_nb_impulsions;
  uint32_t t_dernier = s_t_derniere_us;
  uint32_t periode = s_periode_us;
  interrupts();

  uint32_t maintenant = micros();
  uint32_t nouveaux = nb - s_nb_prec;
  float rpm;

  if (maintenant - t_dernier > DELAI_ARRET_US || periode == 0) {
    rpm = 0.0f;                                // plus de top : arrêté
  } else if (nouveaux >= 2 && (t_dernier - s_t_prec_us) < DELAI_ARRET_US) {
    // (la 2e condition écarte la 1re fenêtre après un arrêt)
    // Période moyenne sur la fenêtre (plus stable qu'une seule période)
    float periode_moy = (float)(t_dernier - s_t_prec_us) / (float)nouveaux;
    rpm = 60.0e6f / (periode_moy * IMPULSIONS_PAR_TOUR);
  } else {
    // Vitesse lente : moins de 2 tops en 10 ms, on prend la dernière période
    rpm = 60.0e6f / ((float)periode * IMPULSIONS_PAR_TOUR);
  }
  if (nouveaux > 0) {
    s_nb_prec = nb;
    s_t_prec_us = t_dernier;
  }

  float omega_rouleau = rpm * (2.0f * PI / 60.0f);       // rad/s
  g_mesures.rpm_rouleau = rpm;
  g_mesures.vitesse_kmh = omega_rouleau * RAYON_ROULEAU_M * 3.6f;

  // --- Couple : moyenne des échantillons de la fenêtre ---
  if (s_nb_adc > 0) {
    float adc_moy = (float)s_somme_adc / (float)s_nb_adc;
    s_somme_adc = 0;
    s_nb_adc = 0;
    float tension = adc_moy * TENSION_REF_ADC_V / 1023.0f;

    if (tension < COUPLE_TENSION_MIN_V || tension > COUPLE_TENSION_MAX_V) {
      // Plusieurs fenêtres de suite hors plage : capteur débranché
      if (s_nb_hors_plage < 255) s_nb_hors_plage++;
      if (s_nb_hors_plage >= COUPLE_NB_HORS_PLAGE_DEFAUT) {
        defaut(DEFAUT_CAPTEUR_COUPLE);
      }
    } else {
      s_nb_hors_plage = 0;
    }
    g_mesures.couple_rouleau_Nm = (tension - COUPLE_ZERO_V) * COUPLE_NM_PAR_V;
  }

  g_mesures.puissance_W = g_mesures.couple_rouleau_Nm * omega_rouleau;

  // --- Survitesse ---
  if (rpm > RPM_SURVITESSE) {
    defaut(DEFAUT_SURVITESSE);
  }
}
