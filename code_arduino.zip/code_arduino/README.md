# Code Arduino Mega du banc Ecoshell : partie autonome

Programme de la carte shield Arduino Mega 2560 (carte V1.0), écrit d'après les organigrammes corrigés (`organigrammes/organigrammes_arduino_mega.html`) et les schémas `PCB_projet_Ecoshell/`. Il couvre tout ce qui fonctionne sans le PC : mesures, température, ventilation, frein à hystérésis, arrêt d'urgence et modes du banc.

**Hors périmètre** : la liaison PC (commandes, trame DATA) et la liaison SPI avec le prototype. Elles se brancheront sur les points d'accroche décrits plus bas, sans modifier le reste.

## Ouvrir et compiler

1. Ouvrir `banc_ecoshell/banc_ecoshell.ino` dans l'IDE Arduino (les autres fichiers du dossier s'ouvrent en onglets).
2. Installer avec le gestionnaire de bibliothèques : **OneWire** (Paul Stoffregen) et **DallasTemperature** (Miles Burton).
3. Carte : « Arduino Mega or Mega 2560 », processeur ATmega2560.

Compilation vérifiée le 2026-10-19 (après l'ajout de la pente) avec avr-gcc 7.3 (le même que l'IDE), cœur Arduino AVR 1.8.6, OneWire et DallasTemperature : 14,7 Ko de programme (5 %) et 843 octets de RAM (10 %), sans avertissement. Le programme n'a pas encore tourné sur la carte réelle.

## Fichiers

| Fichier | Rôle |
|---|---|
| `config.h` | Broches, seuils et constantes. Tout ce qui est marqué `[HYPOTHÈSE]` est à valider. |
| `banc.h` | Modes, causes de défaut, structure `Mesures`, déclarations. |
| `banc_ecoshell.ino` | `setup()`, `loop()` et cadencement des tâches (1 ms, 10 ms, 50 ms, 1 s), chien de garde. |
| `mesures.cpp` | Vitesse par interruption sur D2 (60 imp/tr), couple moyenné sur A0, puissance, survitesse. |
| `frein.cpp` | PWM complémentaire 20 kHz sur Timer 4 (D6/D7, temps mort 0,5 µs), anticipation + correcteur PI, freinage de fin, freinage en défaut. |
| `thermique.cpp` | DS18B20 sur D48 sans attente, ventilateurs sur D42 (60 / 50 °C), surchauffe à 100 °C. |
| `etats.cpp` | Modes ATTENTE, ESSAI, FREINAGE, DÉFAUT ; frein d'urgence D3 ; conditions de démarrage et d'acquittement. |
| `crochets.cpp` | Fonctions vides pour la liaison PC et le prototype. |

## Ce que fait le programme

- **Démarrage** : frein coupé, ventilateurs coupés, SPI et MAX485 au repos, puis mode ATTENTE (ou DÉFAUT si le frein d'urgence est déjà serré). Le banc ne démarre jamais seul.
- **ESSAI** : la consigne de couple au volant est suivie par anticipation (couple → courant → rapport cyclique) corrigée par un PI. Le PI compare la consigne au couple du frein estimé à partir du couplemètre : `C_rouleau / 4 − J_volant × dω/dt`. Sans ce retrait de l'inertie, le PI combattrait le volant à chaque accélération.
- **Pente** : `definirPente(p)` accepte 0 à 6 % dans tous les modes, même pendant l'essai, et la garde pour l'essai suivant. Le couple voulu au volant vaut m·g·p × r / 4 = 0,2200 N·m par % (115 kg, rouleau de 78 mm ; 3 % → 0,66 N·m), le même à toute vitesse. Au départ de l'essai et à chaque changement de pente, le couple rejoint la nouvelle valeur par rampe de 0,5 N·m/s (environ 2,3 % de pente par seconde), sans à-coup sur le pneu. Si le frein est au maximum et que le couple mesuré reste sous la consigne pendant 1 s, `frein_sature` passe à 1 et `evenementSaturationFrein(true)` est appelée : la pente demandée n'est plus tenue (bobine chaude ou pente proche de 6 %).
- **FREINAGE** (fin d'essai) : le couple monte par rampe (0,5 N·m/s), à partir du couple appliqué à ce moment, jusqu'à 1,3 N·m au volant, puis retour en ATTENTE sous 5 tr/min.
- **DÉFAUT** (frein d'urgence, surchauffe, sonde absente, couplemètre débranché, survitesse) : ventilateurs en marche, frein à hystérésis en boucle ouverte à α = 0,95 pour aider le frein à disque tant que le rouleau tourne et que la bobine est sous 100 °C, puis coupé. Sortie seulement après `demanderAcquittement()` avec D3 relâché, rouleau arrêté, sonde et couplemètre valides et T < 95 °C.
- **Démarrage refusé** si le frein d'urgence est serré, si le rouleau tourne, si la bobine est à 95 °C ou plus, ou si un capteur ne répond pas.
- **Chien de garde** matériel de 250 ms : si le programme se bloque, la carte redémarre avec le frein coupé.

## Points d'accroche pour la suite

| Élément | Usage prévu |
|---|---|
| `g_consigne_couple_essai_Nm` | Consigne de couple au volant (N·m) pendant l'essai. Aujourd'hui fixée par `definirPente(p)` (0,2200 N·m par %, 0 à 6 %). |
| `demanderDemarrage()`, `demanderArret()`, `demanderAcquittement()`, `definirPente()` | À appeler sur START, STOP, ACK, SET_SLOPE. Elles renvoient `REP_OK` ou la raison du refus. |
| `signalerActivitePC()` | À appeler à chaque message du PC. Passer `CONTROLE_PC_ACTIF` à `true` pour mettre le banc en défaut après 1 s de silence pendant un essai. |
| `journalMesures(m)` | Appelée toutes les 50 ms avec toutes les mesures : y écrire la trame DATA, envoyée sans bloquer. |
| `evenementDefaut()`, `evenementChangementMode()` | Pour prévenir le PC (FAULT=cause). |
| `evenementSaturationFrein(s)` | Pour prévenir le PC que la pente n'est plus tenue (BRAKE_SAT=1 / 0). `g_mesures.pente_pct` et `g_mesures.frein_sature` sont aussi dans les mesures, pour la trame DATA. |
| `prototype_tache()` | Pour l'échange SPI avec le dsPIC33 du prototype. |

## Commander la pente depuis le moniteur série (commandes.cpp)

Toujours actif (plus besoin de `CONSOLE_MISE_AU_POINT`). Moniteur série à 115200 bauds, fin de ligne « Nouvelle ligne » :

| Commande | Effet | Réponse |
|---|---|---|
| `p3.5` ou `SET_SLOPE:3.5` | pente 3,5 % (0 à 6 %, virgule acceptée), aussi pendant l'essai | `OK pente=3.50 cible=0.770 N.m` ou `ERR PENTE` (pente en cours gardée) |
| `d` ou `START` | démarrer l'essai | `OK` ou `ERR <raison>` |
| `s` ou `STOP` | freinage de fin | `OK` |
| `a` ou `ACK` | acquitter un défaut | `OK` |
| `m` | toutes les mesures une fois | ligne de mesures |
| `DATA:0` / `DATA:1` | couper / remettre la trame DATA | `OK` |

Toutes les 50 ms : `DATA;t=…;mode=ESSAI;pente=3.50;consigne=0.770;couple=0.765;alpha=0.548;BRAKE_SAT=0;rpm=850.0;T=42.5`. Événements : `BRAKE_SAT=1/0`, `MODE=<mode>`, `FAULT=<cause>`. Taper `DATA:0` pour lire plus facilement les réponses dans le moniteur série. Compilé le 2026-11-06 : 19,0 Ko de flash, 1,1 Ko de RAM.

## Pente et consigne de vitesse

Les organigrammes A (consigne de vitesse, Mega) et B (dsPIC de la voiture) vont avec la pente : pendant l'essai, le frein impose la pente et le PI de vitesse (100 ms) monte le rapport cyclique D du moteur pour garder la vitesse demandée. Le couple du frein, la vitesse et D mesurés donnent la puissance qu'il faut à la voiture pour monter cette pente.

- Les deux suivent le même mode : en dehors de ESSAI, D = 0 (octet 5 = 0) et le frein est coupé ou en freinage de fin ; en DÉFAUT, D = 0 et le frein aide le frein à disque.
- La boucle de couple du frein (10 ms) est 10 fois plus rapide que celle de vitesse (100 ms) : elles ne se battent pas, et le frein régule un couple, pas une vitesse.
- La vitesse affichée utilise le même rayon de 78 mm que l'organigramme A.
- La pente n'a pas besoin d'aller dans la trame SPI 0x55 : la voiture ne s'en sert pas. Les octets 3-4 et 8 restent à 0.
- Limite : à 6 % et 30 km/h il faudrait environ 560 W, le moteur en fait 200. Si D reste bloqué à 0,95 et que la vitesse baisse, c'est la voiture qui ne suit plus, pas le frein.

## Hypothèses à valider

**Broches et câblage**

| Valeur | Choix fait | À vérifier sur |
|---|---|---|
| Broches A0, D2, D3, D6, D7, D42, D48, D53 | Reprises du fichier KiCad V1.0 via la page « Organigrammes du banc d'essai » | Schéma KiCad |
| Niveau actif de D3 (frein d'urgence) | HIGH, entrée en pull-up : contact fermé au repos, un fil coupé déclenche le défaut | Le schéma J5 (vu le 2026-10-29) confirme le contact vers la masse sans tirage sur la carte, donc l'INPUT_PULLUP du code est nécessaire. Reste à savoir si le contact du frein est ouvert ou fermé au repos |
| Niveau de D42 qui allume les ventilateurs | HIGH (transistor NPN BC817) | Schéma 03 |
| Broches DE/RE du MAX485 | Non reliées à l'Arduino (255) | Schéma 02 |
| Frein coupé | Les deux MOSFET bloqués (la bobine se décharge par la diode du MOSFET bas) | Schéma 04, montage de la bobine |
| Signe du couple mesuré | Positif quand la roue entraîne le rouleau | Sens de montage du DYN-200 |

**Seuils et réglages**

| Valeur | Choix fait | Source ou à vérifier |
|---|---|---|
| Sortie analogique du DYN-200 | 0-5 V, zéro à 2,5 V, ±5 N·m | Étiquette et fiche d'étalonnage du DYN-200 |
| Plage valide de A0 | 0,1 à 4,9 V, défaut après 50 ms hors plage | Dépend de la sortie réelle du DYN-200 |
| Courbe couple/courant du frein | Linéaire, 3,75 N·m/A : fiche du frein, 400 mA → 1,50 N·m (Calcul_frein.pdf, 2026-10-29) | Linéarité près de zéro |
| Gains PI | Kp = 0,05, Ki = 0,2 /s, PI actif au-dessus de 20 tr/min | Réglage sur le banc |
| Inertie du volant | 0,045 kg·m² (½ m r², 14,9 kg, Ø 155 mm) | Volant réel (11 ou 14,9 kg selon l'Excel) |
| Survitesse | 1 100 tr/min au rouleau (≈ 33 km/h) | CDC (30 ou 50 km/h) |
| Seuils thermiques | Ventilation 60 / 50 °C, défaut 100 °C, reprise sous 95 °C | Fiche technique du frein |
| Rôle du frein à hystérésis en défaut | Il aide le frein à disque à α = 0,95 | Décision de l'équipe banc |
| Freinage de fin | Rampe 0,5 N·m/s jusqu'à 1,3 N·m au volant | Essais |
| Rayon du rouleau | 78 mm, comme le calcul du frein de l'Excel et l'organigramme de vitesse (n × 0,0294 km/h). Le plan dit Ø 160 mm | Mesure du test FAT 2.2 (`RAYON_ROULEAU_M`) |
| Couple par % de pente | Calculé : 115 × 9,81 × 0,01 × 0,078 / 4 = 0,2200 N·m au volant | Masse prototype + pilote (115 ou 125 kg) |
| Rampe de pente | 0,5 N·m/s au départ et à chaque changement de pente | Ressenti sur le banc |
| Saturation du frein | Alpha au maximum et couple 0,05 N·m sous la consigne pendant 1 s | Essais |
| Cadences et chien de garde | 1 / 10 / 50 ms / 1 s, chien de garde 250 ms | Par défaut |

## Points d'attention

- **Chien de garde** : certains anciens Mega (bootloader d'origine avant 2013) bouclent sans fin après un reset par chien de garde. Si la carte ne redémarre plus après un blocage, reflasher le bootloader avec l'IDE (« Graver la séquence d'initialisation »).
- **Pente limitée à 6 %** : c'est la limite du frein dimensionné dans l'Excel, alors que le CDC demande jusqu'à 15 % plus roulement et aérodynamique.
- **Filtre de l'entrée vitesse** : à 30 km/h, 60 imp/tr donnent environ 1 kHz ; un filtre RC à 51 Hz comme dans l'Excel écraserait le signal. À contrôler sur le schéma 02 avant le premier essai.
- La lecture de la DS18B20 bloque quelques millisecondes une fois par seconde (recherche de la sonde sur le bus, estimation non mesurée) ; sans effet notable sur la régulation à 10 ms.
