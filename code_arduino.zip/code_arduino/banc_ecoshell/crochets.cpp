// =====================================================================
//  crochets.cpp : points d'accroche pour les parties à venir
// ---------------------------------------------------------------------
//  Ces fonctions sont appelées par le reste du programme mais ne font
//  rien pour l'instant. La liaison PC (trame DATA, réponses OK/ERR) et
//  la liaison SPI avec le prototype viendront les remplir, sans toucher
//  à la partie autonome.
// =====================================================================
#include "banc.h"

// Appelée toutes les 50 ms avec toutes les mesures à jour :
// trame DATA (pente, consigne, couple du frein, alpha, BRAKE_SAT).
void journalMesures(const Mesures& m) {
  commandes_envoyerTrame(m);
}

// Appelée une fois à l'entrée en DÉFAUT.
void evenementDefaut(CauseDefaut cause) {
  Serial.print(F("FAULT="));
  Serial.println(nomDefaut(cause));
}

// Appelée à chaque changement de mode.
void evenementChangementMode(ModeBanc ancien, ModeBanc nouveau) {
  (void)ancien;
  Serial.print(F("MODE="));
  Serial.println(nomMode(nouveau));
}

// Appelée quand le frein ne tient plus la pente demandée (sature = true)
// puis quand il la tient de nouveau (false). Seulement en ESSAI.
void evenementSaturationFrein(bool sature) {
  Serial.println(sature ? F("BRAKE_SAT=1") : F("BRAKE_SAT=0"));
}

// Appelée à chaque tour de loop().
// Plus tard : échange SPI toutes les 100 ms avec le dsPIC33 du prototype
// (consigne de vitesse, tension et courant batterie). Désactivée en V1.
void prototype_tache() {
}

// ----- Libellés, utiles pour la future trame et le débogage ----------
const char* nomMode(ModeBanc m) {
  switch (m) {
    case MODE_ATTENTE:  return "ATTENTE";
    case MODE_ESSAI:    return "ESSAI";
    case MODE_FREINAGE: return "FREINAGE";
    case MODE_DEFAUT:   return "DEFAUT";
  }
  return "?";
}

const char* nomDefaut(CauseDefaut c) {
  switch (c) {
    case DEFAUT_AUCUN:          return "AUCUN";
    case DEFAUT_FREIN_URGENCE:  return "FREIN_URGENCE";
    case DEFAUT_SURCHAUFFE:     return "SURCHAUFFE";
    case DEFAUT_SONDE:          return "SONDE";
    case DEFAUT_CAPTEUR_COUPLE: return "CAPTEUR_COUPLE";
    case DEFAUT_SURVITESSE:     return "SURVITESSE";
    case DEFAUT_PC_MUET:        return "PC_MUET";
  }
  return "?";
}
