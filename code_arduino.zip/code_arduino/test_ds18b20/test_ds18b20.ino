// ============================================================================
//  test_ds18b20.ino : test autonome de la sonde de température du frein
//
//  Carte    : Arduino Mega 2560 enfichée sur PCB_BANC_DE_TEST_V1
//  Sonde    : DS18B20 sur le connecteur J8, ligne TEMP -> broche D48
//             J8-1 = +5 V (fil rouge)
//             J8-2 = DQ, données (fil jaune), pull-up R25 4,7 k vers +5 V
//                    déjà sur la carte, puis R24 100 ohms vers D48
//             J8-3 = GND (fil noir)
//             J8-4 = non connecté
//
//  Bibliothèques : OneWire (Paul Stoffregen), DallasTemperature (Miles Burton)
//  Moniteur série : 115200 bauds. Une mesure par seconde.
// ============================================================================

#include <OneWire.h>
#include <DallasTemperature.h>

const uint8_t BROCHE_SONDE_TEMP = 48;   // même valeur que config.h du banc

OneWire           bus(BROCHE_SONDE_TEMP);
DallasTemperature sonde(&bus);
DeviceAddress     adresse;
bool              sonde_trouvee = false;

// ---------------------------------------------------------------------------
//  Vérifie le pull-up de la ligne DQ sans aucune sonde nécessaire.
//  On tire la ligne à 0 V, on la relâche, et on regarde si elle remonte
//  à 5 V en 20 µs. Avec 4,7 k elle remonte en moins de 2 µs ; sans pull-up
//  elle reste flottante (souvent à 0).
//  Renvoie 0 = OK, 1 = pull-up absent, 2 = ligne collée à la masse.
// ---------------------------------------------------------------------------
uint8_t testerLigne() {
  uint8_t hauts = 0;
  for (uint8_t i = 0; i < 10; i++) {
    pinMode(BROCHE_SONDE_TEMP, OUTPUT);
    digitalWrite(BROCHE_SONDE_TEMP, LOW);
    delayMicroseconds(10);
    pinMode(BROCHE_SONDE_TEMP, INPUT);          // relâchée, sans pull-up interne
    delayMicroseconds(20);
    if (digitalRead(BROCHE_SONDE_TEMP) == HIGH) hauts++;
    delay(1);
  }
  if (hauts == 10) return 0;

  // La ligne ne remonte pas seule : on essaie avec le pull-up interne (~35 k).
  pinMode(BROCHE_SONDE_TEMP, INPUT_PULLUP);
  delay(2);
  bool haut_avec_interne = (digitalRead(BROCHE_SONDE_TEMP) == HIGH);
  pinMode(BROCHE_SONDE_TEMP, INPUT);
  return haut_avec_interne ? 1 : 2;
}

void afficherAdresse(const DeviceAddress a) {
  for (uint8_t i = 0; i < 8; i++) {
    if (a[i] < 0x10) Serial.print('0');
    Serial.print(a[i], HEX);
    if (i < 7) Serial.print(':');
  }
}

// Cherche la sonde sur le bus. Renvoie true si un DS18B20 valide est trouvé.
bool chercherSonde() {
  sonde.begin();
  uint8_t n = sonde.getDeviceCount();
  if (n == 0) return false;

  if (!sonde.getAddress(adresse, 0)) return false;
  if (OneWire::crc8(adresse, 7) != adresse[7]) {
    Serial.println(F("  ! Adresse reçue avec une erreur de CRC : liaison perturbée (fil trop long, mauvais contact ?)"));
    return false;
  }

  Serial.print(F("  Sonde trouvée ("));
  Serial.print(n);
  Serial.print(F(" sur le bus), adresse "));
  afficherAdresse(adresse);
  Serial.println();
  if (adresse[0] != 0x28) {
    Serial.print(F("  ! Code famille 0x"));
    Serial.print(adresse[0], HEX);
    Serial.println(F(" : ce n'est pas un DS18B20 (0x28 attendu)."));
  }
  if (sonde.readPowerSupply(adresse)) {
    Serial.println(F("  ! Sonde en alimentation parasite : le fil rouge n'est pas sur J8-1 (+5 V)."));
  }
  sonde.setResolution(adresse, 12);
  sonde.setWaitForConversion(true);   // test simple : on attend les 750 ms
  return true;
}

void diagnostiquer() {
  Serial.println(F("Contrôle de la ligne DQ (J8-2 / D48)..."));
  switch (testerLigne()) {
    case 0:
      Serial.println(F("  Pull-up présent : la ligne remonte bien à 5 V."));
      break;
    case 1:
      Serial.println(F("  ! PULL-UP ABSENT : la ligne ne remonte pas seule."));
      Serial.println(F("    Vérifier R25 (4,7 k entre J8-2 et +5 V) et la présence du +5 V sur J8-1."));
      break;
    case 2:
      Serial.println(F("  ! LIGNE COLLÉE À 0 V : court-circuit DQ/GND, sonde branchée à l'envers,"));
      Serial.println(F("    ou TVS D9 en défaut. Débrancher la sonde et relancer pour situer le problème."));
      break;
  }

  sonde_trouvee = chercherSonde();
  if (!sonde_trouvee) {
    Serial.println(F("  ! AUCUNE SONDE DÉTECTÉE sur D48."));
    Serial.println(F("    Vérifier : J8-1 rouge (+5 V), J8-2 jaune (DQ), J8-3 noir (GND)."));
  }
}

void setup() {
  Serial.begin(115200);
  while (!Serial) {}
  Serial.println();
  Serial.println(F("=== Test DS18B20, connecteur J8, broche D48 ==="));
  diagnostiquer();
}

void loop() {
  static uint32_t derniere = 0;
  if (millis() - derniere < 1000) return;
  derniere = millis();

  if (!sonde_trouvee) {
    diagnostiquer();                  // on réessaie chaque seconde (branchement à chaud)
    return;
  }

  sonde.requestTemperaturesByAddress(adresse);
  float t = sonde.getTempC(adresse);

  if (t == DEVICE_DISCONNECTED_C) {
    Serial.println(F("! Sonde perdue (pas de réponse ou CRC faux). Nouvelle recherche..."));
    sonde_trouvee = false;
    return;
  }
  if (t == 85.0f) {
    // 85 °C est la valeur de démarrage de la DS18B20 : souvent un défaut d'alimentation.
    Serial.println(F("T = 85.0 °C  (valeur de mise sous tension : vérifier le +5 V si elle persiste)"));
    return;
  }

  Serial.print(F("T = "));
  Serial.print(t, 2);
  Serial.println(F(" °C"));
}
