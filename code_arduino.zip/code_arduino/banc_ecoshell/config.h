// =====================================================================
//  config.h : broches, seuils et constantes du banc Ecoshell
// ---------------------------------------------------------------------
//  Toutes les valeurs marquées [HYPOTHÈSE] sont à valider sur la carte
//  réelle ou avec la fiche technique du composant (voir README.md).
// =====================================================================
#pragma once
#include <Arduino.h>

// ---------------------------------------------------------------------
//  Broches (carte shield V1.0, d'après le fichier KiCad et le firmware
//  existant)
// ---------------------------------------------------------------------
const uint8_t BROCHE_COUPLE        = A0;  // SIG_OUT du DYN-200 (analogique)
const uint8_t BROCHE_VITESSE       = 2;   // RPM+ via optocoupleur U6
const uint8_t BROCHE_FREIN_URGENCE = 3;   // contact FREIN (J5)
const uint8_t BROCHE_SONDE_TEMP    = 48;  // DS18B20, bus 1-Wire (R25 4,7 k)
const uint8_t BROCHE_PWMH          = 6;   // OC4A -> MIC4104 HI (MOSFET haut)
const uint8_t BROCHE_PWML          = 7;   // OC4B -> MIC4104 LI (MOSFET bas)
const uint8_t BROCHE_VENTILATEURS  = 42;  // BC817 -> relais K1 et K2
const uint8_t BROCHE_SPI_SS        = 53;  // SS du SPI vers le prototype

// [HYPOTHÈSE] Broches DE / RE du MAX485 : non lisibles sur les captures.
// Si elles sont reliées à l'Arduino, mettre leur numéro ici pour que le
// MAX485 soit rendu muet au démarrage. 255 = non relié.
const uint8_t BROCHE_MAX485_DE     = 255;
const uint8_t BROCHE_MAX485_RE     = 255;

// [HYPOTHÈSE] Niveau lu sur D3 quand le frein d'arrêt d'urgence est serré.
// Schéma J5 : contact entre FREIN et GND, sans résistance de tirage sur la
// carte -> l'INPUT_PULLUP de etats.cpp est indispensable.
// Choix par défaut « sécurité positive » : entrée en pull-up, contact
// fermé au repos vers GND ; contact ouvert OU fil coupé = HIGH = urgence.
const uint8_t FREIN_URGENCE_NIVEAU_ACTIF = HIGH;

// [HYPOTHÈSE] Niveau de D42 qui colle les relais (transistor NPN BC817).
const uint8_t VENTILATEURS_NIVEAU_ON = HIGH;

// ---------------------------------------------------------------------
//  Cadences des tâches (ms) : aucune tâche n'utilise delay()
// ---------------------------------------------------------------------
const uint16_t PERIODE_ECHANTILLON_MS = 1;     // lecture A0
const uint16_t PERIODE_REGULATION_MS  = 10;    // vitesse, couple, frein
const uint16_t PERIODE_JOURNAL_MS     = 50;    // crochet journalMesures()
const uint16_t PERIODE_THERMIQUE_MS   = 1000;  // DS18B20 + ventilation

// ---------------------------------------------------------------------
//  Mécanique (Excel « Calcul »)
// ---------------------------------------------------------------------
// [HYPOTHÈSE] Rayon du rouleau au contact du pneu : 78 mm, comme le
// calcul du frein de l'Excel et l'organigramme de vitesse
// (v = n x 0,0294 km/h, 30 km/h <-> 1 020 tr/min). Le plan donne Ø 160 mm
// (80 mm) : la mesure du test FAT 2.2 tranchera, changer seulement ici.
const float RAYON_ROULEAU_M      = 0.078f;
const float RAPPORT_COURROIE     = 4.0f;    // volant = 4 x rouleau
const uint8_t IMPULSIONS_PAR_TOUR = 60;     // DYN-200, sur l'arbre du rouleau

// [HYPOTHÈSE] Inertie du volant (kg.m²) : ½ m r² avec 14,9 kg et Ø 155 mm.
// Sert à retirer l'effet d'inertie du couple mesuré (voir frein.cpp).
// Mettre 0 pour ne pas compenser.
const float INERTIE_VOLANT_KGM2  = 0.045f;

// ---------------------------------------------------------------------
//  Vitesse
// ---------------------------------------------------------------------
const uint32_t DELAI_ARRET_US        = 500000UL; // plus de top depuis 0,5 s -> arrêté
const float    RPM_ARRET             = 5.0f;     // en dessous : rouleau considéré arrêté
// [HYPOTHÈSE] Survitesse : 30 km/h ≈ 1 020 tr/min au rouleau, marge de 8 %.
const float    RPM_SURVITESSE        = 1100.0f;

// ---------------------------------------------------------------------
//  Couplemètre DYN-200 sur A0
// ---------------------------------------------------------------------
// [HYPOTHÈSE] Sortie 0-5 V, zéro à 2,5 V, ±5 N·m pleine échelle.
// À recopier depuis l'étiquette / la fiche d'étalonnage du DYN-200.
const float COUPLE_ZERO_V         = 2.50f;
const float COUPLE_NM_PAR_V       = 2.00f;   // 5 N·m / 2,5 V
const float TENSION_REF_ADC_V     = 5.00f;
// Plage plausible : en dehors, le capteur est considéré débranché.
const float COUPLE_TENSION_MIN_V  = 0.10f;
const float COUPLE_TENSION_MAX_V  = 4.90f;
const uint8_t COUPLE_NB_HORS_PLAGE_DEFAUT = 5;  // 5 x 10 ms consécutifs

// ---------------------------------------------------------------------
//  Frein à hystérésis (bobine 64 Ω sous 24 V)
// ---------------------------------------------------------------------
const float TENSION_FREIN_V       = 24.0f;
const float RESISTANCE_BOBINE_OHM = 64.0f;
// Couple au volant pour 1 % de pente : m.g.(1/100) x rayon du rouleau
// / rapport = 115 x 9,81 x 0,01 x 0,078 / 4 = 0,2200 N·m par %
// (l'Excel donne 0,2198 avec g = 9,8). Suit le rayon et la masse.
// [HYPOTHÈSE] Masse prototype + pilote : 115 kg (Excel ; 125 kg ailleurs).
const float MASSE_PROTO_KG        = 115.0f;
const float GRAVITE_M_S2          = 9.81f;
const float COUPLE_PAR_PCT_PENTE  = MASSE_PROTO_KG * GRAVITE_M_S2 * 0.01f
                                    * RAYON_ROULEAU_M / RAPPORT_COURROIE;
const float PENTE_MAX_PCT         = 6.0f;    // limite physique du frein actuel
// Changement de pente pendant l'essai (et départ de l'essai) : le couple
// passe à la nouvelle valeur par rampe, sans à-coup sur le pneu.
// 0,5 N·m/s au volant ≈ 2,3 % de pente par seconde.
const float RAMPE_PENTE_NM_PAR_S  = 0.50f;
// Frein saturé : alpha au maximum et couple du frein encore inférieur à
// la consigne de plus de SATURATION_ECART_NM pendant SATURATION_DELAI_MS.
// La pente demandée n'est alors plus tenue (bobine chaude, pente proche
// de 6 %) : le signaler à l'opérateur.
const float    SATURATION_ECART_NM = 0.05f;   // ≈ 0,2 % de pente
const uint16_t SATURATION_DELAI_MS = 1000;
// Courbe couple/courant : fiche du frein, 400 mA -> 1,50 N·m, soit
// 3,75 N·m/A (Calcul_frein.pdf). Supposée linéaire : la fiche est
// moins précise près de zéro, le PI rattrape l'écart.
const float FREIN_NM_PAR_A        = 3.75f;

const uint16_t PWM_TOP            = 400;   // Timer 4 phase correcte -> 20 kHz
const uint8_t  PWM_TEMPS_MORT     = 8;     // 8 pas = 0,5 µs
const float    ALPHA_MAX          = 0.95f; // laisse le bootstrap se recharger

// [HYPOTHÈSE] Gains du correcteur PI, à régler sur le banc.
// Kp en (rapport cyclique) / (N·m), Ki en (rapport cyclique) / (N·m.s).
const float PI_KP                 = 0.05f;
const float PI_KI                 = 0.20f;
const float PI_RPM_MIN            = 20.0f;  // PI actif seulement au-dessus
// Accélération du volant au-delà de laquelle l'intégrale est figée
// (rad/s²) : la compensation d'inertie est alors trop incertaine.
const float PI_ACCEL_MAX          = 50.0f;

// Freinage de fin d'essai : rampe du couple jusqu'au couple d'arrêt.
const float COUPLE_ARRET_NM       = 1.30f;  // au volant, ~ alpha max
const float RAMPE_ARRET_NM_PAR_S  = 0.50f;
// [HYPOTHÈSE] En DÉFAUT, le frein à hystérésis aide le frein à disque.
// Avec ce frein (1,3 N·m au volant), on reste loin de l'adhérence
// pneu/rouleau, donc pas de limitation supplémentaire.
const float ALPHA_URGENCE         = ALPHA_MAX;

// ---------------------------------------------------------------------
//  Thermique (seuils repris du firmware existant)
// ---------------------------------------------------------------------
// [HYPOTHÈSE] À confirmer avec la fiche technique du frein.
const float TEMP_VENTIL_ON_C      = 60.0f;
const float TEMP_VENTIL_OFF_C     = 50.0f;
const float TEMP_DEFAUT_C         = 100.0f;
const float TEMP_REPRISE_C        = 95.0f;
const uint8_t SONDE_NB_ECHECS_DEFAUT = 2;   // 2 lectures ratées de suite

// ---------------------------------------------------------------------
//  Liaison PC (hors périmètre de cette version)
// ---------------------------------------------------------------------
// Passer à true quand la liaison PC sera écrite : le banc se mettra alors
// en défaut si le PC se tait plus de DELAI_PC_MUET_MS pendant un essai.
const bool     CONTROLE_PC_ACTIF  = false;
const uint32_t DELAI_PC_MUET_MS   = 1000;
