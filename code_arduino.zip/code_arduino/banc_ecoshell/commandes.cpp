// =====================================================================
//  commandes.cpp : commandes série et trame DATA (organigrammes C et D)
// ---------------------------------------------------------------------
//  Chemin : opérateur -> moniteur série du PC -> câble USB -> RX0 de la
//  Mega. Moniteur série à 115200 bauds, fin de ligne « Nouvelle ligne ».
//
//  Commandes acceptées (une par ligne) :
//    p3.5  ou  SET_SLOPE:3.5   pente 3,5 % (0 à 6 %), aussi pendant l'essai
//    d     ou  START           démarrer l'essai
//    s     ou  STOP            freinage de fin d'essai
//    a     ou  ACK             acquitter un défaut
//    m                         afficher toutes les mesures une fois
//    DATA:0 / DATA:1           couper / remettre la trame DATA (50 ms)
//
//  Réponse à chaque commande : « OK » ou « ERR <raison> ». Une pente
//  refusée (hors 0 à 6 %, ou pas un nombre) laisse la pente en cours.
//
//  Trame DATA toutes les 50 ms (vers le PC) :
//    DATA;t=12345;mode=ESSAI;pente=3.50;consigne=0.770;couple=0.765;
//    alpha=0.548;BRAKE_SAT=0;rpm=850.0;T=42.5
//  (sur une seule ligne). Événements envoyés dès qu'ils arrivent :
//    BRAKE_SAT=1 / BRAKE_SAT=0, MODE=<mode>, FAULT=<cause>
// =====================================================================
#include "banc.h"

static bool s_trame_active = true;

// ----- Petits outils -------------------------------------------------
// Compare sans tenir compte des majuscules ; renvoie la suite de la
// ligne si elle commence par « prefixe », sinon NULL.
static const char* commencePar(const char* ligne, const char* prefixe) {
  while (*prefixe) {
    if (toupper((unsigned char)*ligne) != toupper((unsigned char)*prefixe)) return NULL;
    ligne++;
    prefixe++;
  }
  return ligne;
}

// Lit un nombre décimal (« 3.5 » ou « 3,5 ») ; NAN si ce n'est pas un
// nombre complet, pour que definirPente() réponde ERR au lieu de
// prendre 0 % sans le dire.
static float lireNombre(const char* texte) {
  char tampon[12];
  uint8_t n = 0;
  while (*texte == ' ') texte++;
  while (*texte && n < sizeof(tampon) - 1) {
    tampon[n++] = (*texte == ',') ? '.' : *texte;
    texte++;
  }
  tampon[n] = '\0';
  if (n == 0 || *texte) return NAN;           // vide ou trop long
  char* fin;
  double v = strtod(tampon, &fin);
  while (*fin == ' ') fin++;
  if (*fin != '\0') return NAN;               // reste du texte : refusé
  return (float)v;
}

static const char* texteReponse(Reponse r) {
  switch (r) {
    case REP_OK:                return "OK";
    case REP_ERR_MODE:          return "ERR MODE";
    case REP_ERR_FREIN_URGENCE: return "ERR FREIN_URGENCE";
    case REP_ERR_VITESSE:       return "ERR VITESSE";
    case REP_ERR_TEMPERATURE:   return "ERR TEMPERATURE";
    case REP_ERR_CAPTEUR:       return "ERR CAPTEUR";
    case REP_ERR_PENTE:         return "ERR PENTE";
  }
  return "ERR";
}

static void afficherMesures() {
  const Mesures& m = g_mesures;
  Serial.print(nomMode(m.mode));
  Serial.print(F(" defaut="));   Serial.print(nomDefaut(m.defaut));
  Serial.print(F(" rpm="));      Serial.print(m.rpm_rouleau, 1);
  Serial.print(F(" km/h="));     Serial.print(m.vitesse_kmh, 1);
  Serial.print(F(" C_rouleau=")); Serial.print(m.couple_rouleau_Nm, 3);
  Serial.print(F(" C_frein="));  Serial.print(m.couple_frein_estime_Nm, 3);
  Serial.print(F(" P="));        Serial.print(m.puissance_W, 1);
  Serial.print(F(" T="));        Serial.print(m.temperature_C, 1);
  Serial.print(F(" pente="));    Serial.print(m.pente_pct, 2);
  Serial.print(F(" cible="));    Serial.print(g_consigne_couple_essai_Nm, 3);
  Serial.print(F(" consigne=")); Serial.print(m.consigne_couple_Nm, 3);
  Serial.print(F(" alpha="));    Serial.print(m.alpha, 3);
  Serial.print(F(" OCR4A="));    Serial.print((uint16_t)(m.alpha * PWM_TOP + 0.5f));
  Serial.print(F(" BRAKE_SAT=")); Serial.print(m.frein_sature ? 1 : 0);
  Serial.print(F(" ventil="));   Serial.print(m.ventilateurs_on ? 1 : 0);
  Serial.print(F(" D3="));       Serial.println(m.frein_urgence_serre ? 1 : 0);
}

// ----- Traitement d'une ligne (organigramme C, cases 3 à 6) ----------
static void traiterLigne(const char* ligne) {
  signalerActivitePC();
  const char* reste;

  // Pente : « p3.5 » (moniteur série) ou « SET_SLOPE:3.5 » (interface PC)
  if ((reste = commencePar(ligne, "SET_SLOPE:")) != NULL ||
      ((ligne[0] == 'p' || ligne[0] == 'P') && (reste = ligne + 1))) {
    // definirPente() vérifie 0 <= p <= 6 %, garde la pente (pente_pct)
    // et calcule la cible = 0,2200 N·m x p ; la rampe se fait dans
    // frein_reguler() toutes les 10 ms.
    Reponse r = definirPente(lireNombre(reste));
    Serial.print(texteReponse(r));
    if (r == REP_OK) {
      Serial.print(F(" pente="));  Serial.print(g_mesures.pente_pct, 2);
      Serial.print(F(" cible="));  Serial.print(g_consigne_couple_essai_Nm, 3);
      Serial.print(F(" N.m"));
    }
    Serial.println();
    return;
  }

  if ((reste = commencePar(ligne, "DATA:")) != NULL) {
    if (reste[0] == '0' || reste[0] == '1') {
      s_trame_active = (reste[0] == '1');
      Serial.println(F("OK"));
    } else {
      Serial.println(F("ERR"));
    }
    return;
  }

  Reponse r;
  if (commencePar(ligne, "START") || strcmp(ligne, "d") == 0)      r = demanderDemarrage();
  else if (commencePar(ligne, "STOP") || strcmp(ligne, "s") == 0)  r = demanderArret();
  else if (commencePar(ligne, "ACK") || strcmp(ligne, "a") == 0)   r = demanderAcquittement();
  else if (strcmp(ligne, "m") == 0) { afficherMesures(); return; }
  else { Serial.println(F("ERR COMMANDE")); return; }
  Serial.println(texteReponse(r));
}

// ----- Lecture du port série, sans bloquer (à chaque tour de loop) ---
void commandes_tache() {
  static char ligne[24];
  static uint8_t n = 0;
  static bool trop_longue = false;
  // Au plus 32 caractères par tour pour ne pas retarder la régulation
  for (uint8_t i = 0; i < 32 && Serial.available(); i++) {
    char c = Serial.read();
    if (c != '\n' && c != '\r') {
      if (n < sizeof(ligne) - 1) ligne[n++] = c;
      else trop_longue = true;
      continue;
    }
    if (n == 0 && !trop_longue) continue;     // ligne vide (\r\n)
    ligne[n] = '\0';
    if (trop_longue) Serial.println(F("ERR COMMANDE"));
    else             traiterLigne(ligne);
    n = 0;
    trop_longue = false;
  }
}

// ----- Trame DATA, toutes les 50 ms (organigramme D, case 20) --------
// La trame fait environ 110 caractères, soit 10 ms à 115200 bauds sur
// 50 ms. Le tampon d'émission de la Mega fait 63 octets : on n'envoie
// que s'il est presque vide (trame précédente partie), sinon on saute
// cette trame. L'écriture peut alors attendre au plus ~5 ms, ce qui
// décale un peu un cycle de 10 ms sans le sauter.
void commandes_envoyerTrame(const Mesures& m) {
  if (!s_trame_active) return;
  if (Serial.availableForWrite() < 60) return;
  Serial.print(F("DATA;t="));      Serial.print(m.t_ms);
  Serial.print(F(";mode="));       Serial.print(nomMode(m.mode));
  Serial.print(F(";pente="));      Serial.print(m.pente_pct, 2);
  Serial.print(F(";consigne="));   Serial.print(m.consigne_couple_Nm, 3);
  Serial.print(F(";couple="));     Serial.print(m.couple_frein_estime_Nm, 3);
  Serial.print(F(";alpha="));      Serial.print(m.alpha, 3);
  Serial.print(F(";BRAKE_SAT="));  Serial.print(m.frein_sature ? 1 : 0);
  Serial.print(F(";rpm="));        Serial.print(m.rpm_rouleau, 1);
  Serial.print(F(";T="));          Serial.println(m.temperature_C, 1);
}
